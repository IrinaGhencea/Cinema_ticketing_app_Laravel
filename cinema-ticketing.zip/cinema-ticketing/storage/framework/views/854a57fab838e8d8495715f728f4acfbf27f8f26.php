

<?php $__env->startSection('content'); ?>

    <h1>Tickets</h1>

    <a href="<?php echo e(route('movies.create')); ?>" class="btn btn-primary">Add New Ticket</a>

    <table class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Name</th>
                <th>Email</th>
                <th>Quantity</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($ticket->title); ?></td>
                    <td><?php echo e($ticket->name); ?></td>
                    <td><?php echo e($ticket->email); ?></td>
                    <td><?php echo e($ticket->quantity); ?></td>
                    <td>
                        <a href="<?php echo e(route('movies.edit', $ticket)); ?>" class="btn btn-primary">Edit</a>
                        
                        <form action="<?php echo e(route('movies.destroy', $ticket)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No tickets found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anton\OneDrive\Desktop\cinema\cinema-ticketing\resources\views/movies/index.blade.php ENDPATH**/ ?>