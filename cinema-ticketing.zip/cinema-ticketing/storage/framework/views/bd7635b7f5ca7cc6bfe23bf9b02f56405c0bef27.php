


<?php $__env->startSection('content'); ?>
    <h1>My Tickets</h1>
    
    <?php if($tickets->isEmpty()): ?>
        <p>You have no tickets yet.</p>
    <?php else: ?>
        <ul>
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($ticket->seat_number); ?> - $<?php echo e($ticket->price); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anton\OneDrive\Desktop\cinema\cinema-ticketing\resources\views/tickets/index.blade.php ENDPATH**/ ?>