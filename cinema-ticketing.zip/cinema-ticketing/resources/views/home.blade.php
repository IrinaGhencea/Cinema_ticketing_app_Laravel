@extends('layouts.app')

@section('content')
    <div class="container mt-4">
        <div class="header">
            <h1>Welcome to Cinema Ticketing</h1>
            <p>Your destination for the best movies and convenient ticket booking.</p>
        </div>
        <div class="intro">
            <h2>About Us</h2>
            <p>At Cinema Ticketing, we are passionate about bringing the magic of cinema to your fingertips. Whether you're a movie buff or just looking for a night out with friends, we've got you covered. Our user-friendly platform allows you to browse movies, purchase tickets, and manage your bookings with ease.</p>
        </div>
        <div class="content">
            <h2>Our Services</h2>
            <p>Explore a wide range of services tailored to enhance your movie-going experience:</p>
            <ul>
                <li><strong>Movie Listings:</strong> Discover the latest movies and upcoming releases.</li>
                <li><strong>Online Booking:</strong> Purchase tickets in advance from the comfort of your home.</li>
                <li><strong>Personalized Experience:</strong> Choose your favorite seats and snacks in advance.</li>
                <li><strong>Convenient Access:</strong> Mobile-friendly interface for easy booking on-the-go.</li>
                <li><strong>Customer Support:</strong> Dedicated support to assist with any inquiries or issues.</li>
            </ul>
        </div>
        <div class="content">
            <h2>Why Choose Us?</h2>
            <p>At Cinema Ticketing, we strive to provide:</p>
            <ul>
                <li><strong>Quality:</strong> Enjoy a seamless and hassle-free booking experience.</li>
                <li><strong>Accessibility:</strong> Easily accessible platform for all your movie needs.</li>
                <li><strong>Variety:</strong> Extensive selection of movies to cater to all tastes.</li>
                <li><strong>Security:</strong> Secure payment gateway to ensure your transactions are safe.</li>
                <li><strong>Flexibility:</strong> Multiple payment options and booking schedules to suit your preferences.</li>
            </ul>
        </div>
    </div>
@endsection
