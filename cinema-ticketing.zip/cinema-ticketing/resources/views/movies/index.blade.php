@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>My Tickets</h1>

        <a href="{{ route('tickets.create') }}" class="btn btn-primary mb-3">Add New Ticket</a>

        @if ($tickets->isEmpty())
            <p>No tickets found.</p>
        @else
            <table class="table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Quantity</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($tickets as $ticket)
                        <tr>
                            <td>{{ $ticket->title }}</td>
                            <td>{{ $ticket->name }}</td>
                            <td>{{ $ticket->email }}</td>
                            <td>{{ $ticket->quantity }}</td>
                            <td>
                                <a href="{{ route('tickets.edit', $ticket) }}" class="btn btn-primary">Edit</a>
                                <form action="{{ route('tickets.destroy', $ticket) }}" method="POST" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
@endsection
