<!-- resources/views/movies.blade.php -->

@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Movies</h1>

        <!-- Buy Tickets Button -->
        @foreach($movies as $movie)
            <div class="button-container">
                <a href="{{ route('tickets.create', $movie->id) }}" class="btn btn-primary">Buy Tickets</a>
            </div>
        @endforeach

        <!-- Movie List -->
        <ul class="list-group mt-3">
            @foreach($movies as $movie)
                <li class="list-group-item">
                    <!-- Movie Title -->
                    <span>{{ $movie->title }}</span>

                    <!-- Action Buttons -->
                    <div class="float-right">
                        <!-- Edit Movie Button -->
                        <a href="{{ route('movies.edit', $movie) }}" class="btn btn-primary btn-sm mr-2">Edit</a>

                        <!-- Delete Movie Form -->
                        <form action="{{ route('movies.destroy', $movie) }}" method="POST" style="display: inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>

                        <!-- View Movie Details Button -->
                        <a href="{{ route('movies.show', $movie) }}" class="btn btn-info btn-sm ml-2">View Details</a>
                    </div>
                </li>
            @endforeach
        </ul>
    </div>
@endsection
