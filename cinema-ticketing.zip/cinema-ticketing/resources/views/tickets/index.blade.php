
@extends('layouts.app')

@section('content')
    <h1>My Tickets</h1>
    
    @if ($tickets->isEmpty())
        <p>You have no tickets yet.</p>
    @else
        <ul>
            @foreach ($tickets as $ticket)
                <li>{{ $ticket->seat_number }} - ${{ $ticket->price }}</li>
            @endforeach
        </ul>
    @endif
@endsection
